int pthread_setcancelstate(int __state, int *__oldstate)
{
    return 0;
}